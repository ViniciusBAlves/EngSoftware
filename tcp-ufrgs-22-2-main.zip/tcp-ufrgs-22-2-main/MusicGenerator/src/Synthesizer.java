import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jm.JMC;
import jm.music.data.Note;

public class Synthesizer {
    private SystemStatus status = new SystemStatus();
    private String lastChar = "\0";
    private int lastInstrument;
    private boolean playNextNote;
    private boolean changeInstrument;
    private boolean playSilence;

    public Note getNote() {
        return status.getNextNote();
    }

    public int getInstrument() {
        return status.getInstrument();
    }

    public int getLastInstrument() {
        return lastInstrument;
    }

    public Note getWait() {
        return status.waitNote();
    }

    public double getNoteDurationInSec() {
        return status.getNextNote().getDuration() * 60 / status.getBpm();
    }

    public void readCharacter(String str) {
        playNextNote = false;
        changeInstrument = false;
        playSilence = false;

        Matcher validNote = Pattern.compile("[A-G]").matcher(str);
        Matcher validNoteLower = Pattern.compile("[a-g]").matcher(str);
        Matcher vogal = Pattern.compile("[oiuOIU]").matcher(str);
        Matcher consoante = Pattern.compile("[HJ-NP-TV-Zhj-np-tv-z]").matcher(str);
        Matcher number = Pattern.compile("([0-9])").matcher(str);

        if (validNote.find()) {
            status.setNote(str.charAt(0));
            playNextNote = true;
        }

        else if (validNoteLower.find()) {
            if (isNote()) {
                status.setNote(lastChar.charAt(0));
                playNextNote = true;
            } else {
                playSilence = true;
            }
        }

        else if (vogal.find()) {
            lastInstrument = status.getInstrument();
            status.setInstrument(JMC.HARPSICHORD);
            changeInstrument = true;
        }

        else if (consoante.find()) {
            if (isNote()) {
                status.setNote(lastChar.charAt(0));
                playNextNote = true;
            } else {
                playSilence = true;
            }
        }

        else if (str.equals("?")) {
            status.incOctave();
        }

        else if (str.equals("\n")) {
            lastInstrument = status.getInstrument();
            status.setInstrument(JMC.TUBULAR_BELLS);
            changeInstrument = true;
        }

        else if (str.equals(";")) {
            lastInstrument = status.getInstrument();
            status.setInstrument(JMC.PANFLUTE);
            changeInstrument = true;
        }

        else if (str.equals(",")) {
            lastInstrument = status.getInstrument();
            status.setInstrument(JMC.CHURCH_ORGAN);
            changeInstrument = true;
        }

        else if (str.equals("!")) {
            lastInstrument = status.getInstrument();
            status.setInstrument(JMC.AGOGO);
            changeInstrument = true;
        }

        else if (str.equals(" ")) {
            status.duplicateVolume();
        }

        else if (number.find()) {
            lastInstrument = status.getInstrument();
            status.setInstrument(Integer.parseInt(number.group(1)) + status.getInstrument());
            changeInstrument = true;
        }

        else {
            if (isNote()) {
                status.setNote(lastChar.charAt(0));
                playNextNote = true;
            } else {
                playSilence = true;
            }
        }
        lastChar = str;
    }

    public boolean toPlay() {
        return playNextNote;
    }

    public boolean toChangeInst() {
        return changeInstrument;
    }

    public boolean toWait() {
        return playSilence;
    }

    private boolean isNote() {
        Pattern pattern = Pattern.compile("[A-G]");
        Matcher matcher = pattern.matcher(lastChar);

        if (matcher.find()) {
            return true;
        } else {
            return false;
        }
    }
}
