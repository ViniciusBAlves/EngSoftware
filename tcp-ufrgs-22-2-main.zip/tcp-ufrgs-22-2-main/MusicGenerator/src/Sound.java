public class Sound {
    private Player player = new Player();
    private TextParser textParser = new TextParser();

    public void setText(String text) {
        textParser.setText(text);
        textParser.resetIterator();
        this.create();
    }

    public void play() {
        player.play();
    }

    public void play(String midiFile) {
        player.play(midiFile);
    }

    public void save(String fileName) {
        player.save(fileName);
    }

    private void create() {
        player = new Player();
        while (textParser.hasNext()) {
            String input = textParser.readChar();
            player.addInstruction(input);
        }
        player.closeText();
    }

}
