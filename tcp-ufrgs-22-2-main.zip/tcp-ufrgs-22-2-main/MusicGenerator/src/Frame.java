import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Font;
import java.awt.Insets;

public class Frame extends JFrame implements ActionListener {
    Sound sound = new Sound();

    PlayButton playButton = new PlayButton();
    TitlePanel titlePanel = new TitlePanel();
    MusicTextArea textField = new MusicTextArea();

    LoadButton loadButton = new LoadButton();
    SaveButton saveButton = new SaveButton();
    MidiButton midiButton = new MidiButton();
    FileButton fileButton = new FileButton();

    final int widht = 1024, height = 640;

    public Frame() {

        this.mainFrame();

        this.playButton.addActionListener(this);
        this.loadButton.addActionListener(this);
        this.saveButton.addActionListener(this);
        this.midiButton.addActionListener(this);
        this.fileButton.addActionListener(this);

        this.setLogo();
        this.add(this.titlePanel);
        this.add(this.playButton);
        this.add(this.loadButton);
        this.add(this.saveButton);
        this.add(this.midiButton);
        this.add(this.fileButton);
        this.add(this.textField);

        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == this.playButton) {
            actionPerformer(this.playButton);
        } else if (e.getSource() == this.loadButton) {
            actionPerformer(this.loadButton);
        } else if (e.getSource() == this.saveButton) {
            actionPerformer(this.saveButton);
        } else if (e.getSource() == this.midiButton) {
            actionPerformer(this.midiButton);
        } else if (e.getSource() == this.fileButton) {
            actionPerformer(this.fileButton);
        }
    }

    private void actionPerformer(PlayButton button) {
        sound.setText((this.textField.getText()));
        sound.play();
    }

    private void actionPerformer(LoadButton button) {
        JFileChooser fileChooser = new JFileChooser();
        int response = fileChooser.showOpenDialog(null);

        if (response == JFileChooser.APPROVE_OPTION) {
            String fileName = fileChooser.getSelectedFile().getAbsolutePath();
            String fileContent = getFileContent(fileName);
            this.textField.setText(fileContent);
        }
    }

    private void actionPerformer(SaveButton button) {
        JFileChooser fileChooser = new JFileChooser();
        int response = fileChooser.showSaveDialog(null);

        if (response == JFileChooser.APPROVE_OPTION) {
            String fileName = fileChooser.getSelectedFile().getAbsolutePath();
            String fileContent = this.textField.getText();
            sound.setText(fileContent);
            sound.save(fileName);
        }
    }

    private void actionPerformer(MidiButton button) {
        JFileChooser fileChooser = new JFileChooser();
        int response = fileChooser.showOpenDialog(null);

        if (response == JFileChooser.APPROVE_OPTION) {
            String midiFile = fileChooser.getSelectedFile().getAbsolutePath();
            sound.play(midiFile);
        }
    }

    private void actionPerformer(FileButton button) {
        JFileChooser fileChooser = new JFileChooser();
        int response = fileChooser.showSaveDialog(null);

        if (response == JFileChooser.APPROVE_OPTION) {
            String fileName = fileChooser.getSelectedFile().getAbsolutePath();
            this.saveFileContent(fileName);
        }
    }

    public void mainFrame() {
        this.setTitle("Music Generator");
        this.getContentPane().setBackground(new Color(33, 47, 60));
        this.setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(widht, height);
    }

    private void setLogo() {
        ImageIcon icon = new ImageIcon("MusicGenerator/logo.png");
        this.setIconImage(icon.getImage());
    }

    private String getFileContent(String fileName) {
        String fileContent = "";
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);
            String line;
            while (scanner.hasNextLine()) {
                line = scanner.nextLine();
                fileContent = fileContent.concat(line + "\n");
            }
            scanner.close();
        } catch (FileNotFoundException exc) {
            exc.printStackTrace();
        }
        return fileContent;
    }

    private void saveFileContent(String fileName) {
        String fileContent = this.textField.getText();

        try {
            FileWriter fileWriter = new FileWriter(fileName);
            fileWriter.write(fileContent);
            fileWriter.close();
        } catch (Exception exc) {
            exc.printStackTrace();
        }
    }

    class MusicTextArea extends JTextArea {
        MusicTextArea() {
            this.setBounds(20, 100, 700, 440);
            this.setMargin(new Insets(5, 5, 5, 5));
        }
    }

    class DefaultButton extends JButton {
        DefaultButton() {
            this.setFocusable(false);
            this.setForeground(new Color(214, 234, 248));
            this.setBackground(new Color(93, 109, 126));

        }
    }

    class PlayButton extends DefaultButton {
        PlayButton() {
            this.setBounds(780, 100, 200, 40);
            this.setText("Play Song");
        }
    }

    class LoadButton extends DefaultButton {
        LoadButton() {
            this.setBounds(780, 300, 200, 40);
            this.setText("Load a file");
        }
    }

    class SaveButton extends DefaultButton {
        SaveButton() {
            this.setBounds(780, 400, 200, 40);
            this.setText("Save song");
        }
    }

    class FileButton extends DefaultButton {
        FileButton() {
            this.setBounds(780, 200, 200, 40);
            this.setText("Save file");
        }
    }

    class MidiButton extends DefaultButton {
        MidiButton() {
            this.setBounds(780, 500, 200, 40);
            this.setText("Play MIDI");
        }
    }

    class TitleLabel extends JLabel {
        TitleLabel() {
            this.setText("Write your song!");
            this.setForeground(new Color(214, 234, 248));
            this.setFont(new Font("Roboto", Font.PLAIN, 36));
            this.setHorizontalAlignment(JLabel.CENTER);
            this.setVerticalAlignment(JLabel.TOP);
        }
    }

    class TitlePanel extends JPanel {
        TitlePanel() {
            this.setBounds(0, 0, widht, 50);
            this.setBackground(new Color(27, 38, 49));
            this.addTitleLabel(new TitleLabel());
        }

        public void addTitleLabel(TitleLabel titleLabel) {
            this.add(titleLabel);
        }
    }
}
