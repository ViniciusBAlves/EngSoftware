public class TextParser {
    private String text;
    private int it = 0;

    public int getIterator() {
        return it;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public boolean hasNext() {
        return it < text.length();
    }

    public String readChar() {
        String input = text.substring(it, it + 1);
        it = it + 1;
        return input;
    }

    public void resetIterator() {
        it = 0;
    }
}
