import jm.music.data.Part;
import jm.music.data.Phrase;
import jm.music.data.Score;
import jm.music.data.Note;
import jm.util.Play;
import jm.util.Read;
import jm.util.Write;


public class Player{
    private Synthesizer synth = new Synthesizer();
    private Phrase phrase = new Phrase();
    private Score score = new Score();

    private double currentTime = 0.0;

    private void incTime(){
        currentTime += synth.getNoteDurationInSec();
    }

    private void addNote(){
        Note note = synth.getNote();
        phrase.add(note);
        incTime();
    }

    private void addWait(){
        Note note = synth.getWait();
        phrase.add(note);
        incTime();
    }

    private void changeInstrument(){
        score.add(new Part(phrase, null, synth.getLastInstrument()));
        phrase = new Phrase((double)currentTime);
    }

    public void addInstruction(String str){
        synth.readCharacter(str);
        if (synth.toPlay())
            addNote();
        else if (synth.toWait()){
            addWait();
        }
        else if (synth.toChangeInst()){
            changeInstrument();
        }
    }

    public void closeText(){
        score.addPart(new Part(phrase, null, synth.getInstrument()));
    }

    public void play(){
        Play.midi(score);
    }    

    public void play(String midiFile){
        score = new Score();
        Read.midi(score, midiFile);
        this.play();
    }    

    public void save(String fileName){
        Write.midi(score, fileName);
    }    
}
